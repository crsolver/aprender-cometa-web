`puede_cruzar` se resuelve en una línea, porque la comparación ya es el resultado. "5 o más" se escribe con `>=`.

```cometa
monedas >= 5
```
---
`peaje` tiene tres caminos. Empieza por los más jóvenes. Si el viajero no tiene menos de 12 años, pregunta si tiene menos de 18.

```cometa
si edad < 12 0
osi edad < 18 3
sino 5
```
---
En `saludo`, el parámetro `es_de_noche` ya es `verdadero` o `falso`.

```cometa
si es_de_noche "Buenas noches"
sino "Buenos días"
```
---
`mas_rapido` compara los dos números y devuelve el mayor.

```cometa
si caballo > burro caballo
sino burro
```
