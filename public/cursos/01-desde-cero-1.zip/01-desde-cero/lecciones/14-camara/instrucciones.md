Al final del calabozo está la cámara del tesoro, protegida por varias reglas mágicas. El hechizo que las controla se dañó y ahora todas responden que no. Tu trabajo es escribirlas de nuevo.

## Tu misión

Completa las cinco funciones de `solucion.cometa`.

- `puede_entrar(nivel, tiene_antorcha)` devuelve `verdadero` solo si la persona es de nivel 3 o más y además lleva antorcha.
- `abre_el_cofre(tiene_llave, sabe_hechizo)` devuelve `verdadero` si tiene la llave o si sabe el hechizo. Con cualquiera de los dos basta.
- `es_seguro(hay_trampa)` devuelve `verdadero` cuando en el pasillo no hay trampa.
- `dado_valido(numero)` devuelve `verdadero` si el número está entre 1 y 6, contando también el 1 y el 6.
- `premio(dado)` devuelve el premio que corresponde al dado. Con 1 es `"nada"`, con 2 o 3 es `"moneda"`, con 4 o 5 es `"gema"` y con 6 es `"corona"`. Con cualquier otro número devuelve `"dado inválido"`.

## Lo que necesitas saber

- `&&` significa "y". Da verdadero solo si las dos condiciones son verdaderas.
- `||` significa "o". Da verdadero si al menos una es verdadera.
- `!` significa "no". Invierte un bool.

```cometa
pub fn puede_jugar(edad entero, tiene_permiso bool) bool
	edad >= 8 && tiene_permiso
```

Para elegir entre muchos valores, `casos` es más cómodo que escribir muchos `osi`.

```cometa
pub fn color(numero entero) cadena
	casos numero
		1 => "rojo"
		2, 3 => "verde"
		_ => "sin color"
```

El `_` del final recibe cualquier otro valor y es obligatorio.
