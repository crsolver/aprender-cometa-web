En `total`, el precio se multiplica por la cantidad. Solo tienes que cambiar el `0`.

```cometa
var resultado = precio * cantidad
```
---
`cambio` es una resta. A las monedas que tenías les quitas lo que costó la compra.

```cometa
var resultado = monedas - costo
```
---
El reparto es una división entre enteros.

```cometa
var resultado = monedas / amigos
```

Lo que sobra es el resto de esa división.

```cometa
var resultado = monedas % amigos
```
---
Para el recibo, pon las dos variables dentro del texto con `${}`. Cuida que los dos puntos y los espacios queden igual que en el ejemplo.

```cometa
var texto = "${objeto}: ${total} monedas"
```
