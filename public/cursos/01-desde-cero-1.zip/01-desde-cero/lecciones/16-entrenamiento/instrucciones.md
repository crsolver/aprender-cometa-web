En el campo de entrenamiento todo se hace muchas veces, desde las flexiones hasta los golpes de tambor. La instructora quiere un programa que lleve las cuentas, y para eso vas a necesitar ciclos.

## Tu misión

Completa las cuatro funciones de `solucion.cometa`.

- `flexiones(dias)` devuelve el total de flexiones después de esa cantidad de días. El día 1 haces 1 flexión, el día 2 haces 2, el día 3 haces 3, y así cada día. Con 4 días el total es 1 + 2 + 3 + 4 = 10.
- `tambor(golpes)` devuelve un texto con `"pum"` repetido esa cantidad de veces, con un espacio después de cada uno. Con 3 golpes el texto es `"pum pum pum "`.
- `dias_de_descanso(dias)` devuelve cuántos días de descanso hay entre el día 1 y ese día, contando también ese día. Se descansa los días que son múltiplos de 5, como el 5, el 10 y el 15.
- `potencia(base, exponente)` devuelve la base multiplicada por sí misma tantas veces como diga el exponente. `potencia(2, 3)` es 2 × 2 × 2 = 8.

Las cuatro funciones ya tienen la variable creada y la última línea escrita. Te falta escribir el ciclo que va en medio.

## Lo que necesitas saber

`repetir` recorre un rango. El primer número se incluye y el último no.

```cometa
repetir (1..6) |numero|
	imprimir(numero)   // 1, 2, 3, 4, 5
```

Para que la cuenta llegue hasta `dias`, el rango tiene que ser `1..dias + 1`.

Para acumular un resultado se crea una variable antes del ciclo, se cambia dentro del ciclo y se devuelve al final.

```cometa
pub fn sumar_pares(limite entero) entero
	var suma = 0
	repetir (1..limite + 1) |numero|
		si numero % 2 == 0
			suma += numero
	suma
```

Si no necesitas el número de la vuelta, puedes dejar el ciclo sin las barras.

```cometa
repetir (0..3)
	imprimir("otra vez")
```
