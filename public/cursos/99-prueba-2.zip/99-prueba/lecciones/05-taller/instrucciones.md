Hasta ahora las funciones venían empezadas. En este taller el archivo está casi en blanco y vas a escribir tres funciones completas, con su nombre, sus parámetros y su resultado.

## Tu misión

Escribe estas tres funciones en `solucion.cometa`. Todas llevan `pub` al principio.

- `triple` recibe un `entero` llamado `numero` y devuelve ese número multiplicado por 3.
- `perimetro` recibe dos enteros, `ancho` y `alto`, y devuelve el perímetro de un rectángulo, que es la suma de sus cuatro lados.
- `bienvenida` recibe una `cadena` llamada `nombre` y devuelve un texto como `"¡Bienvenida al taller, Lira!"`.

El programa no va a funcionar hasta que existan las tres. Mientras falte alguna, verás un error como `el módulo solucion no tiene "triple"`. Ese mensaje solo dice que la función todavía no existe, que es justamente lo que tienes que resolver.

## Lo que necesitas saber

Este es un ejemplo de una función completa.

```cometa
pub fn area(ancho entero, alto entero) entero
	ancho * alto
```

Sus partes van en este orden.

- Primero `pub fn` y el nombre de la función.
- Entre paréntesis van los parámetros, cada uno con su nombre y su tipo, separados por comas.
- Después de los paréntesis va el tipo del resultado.
- En la línea siguiente, con un tabulador, va el contenido. La última línea es lo que se devuelve.

Los nombres de las funciones y el orden de los parámetros tienen que ser exactamente los que se piden, porque el resto del programa las llama de esa forma.
