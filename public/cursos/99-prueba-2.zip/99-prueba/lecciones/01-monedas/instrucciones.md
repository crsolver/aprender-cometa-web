Tu héroe encontró un cofre con 10 monedas, pero nadie las ha contado todavía. Es un buen momento para crear tu primera variable.

> En este ejercicio solo importa la parte que está marcada con `ESCRIBE TU CÓDIGO AQUÍ`. No te preocupes si no entiendes el resto del código, porque lo iremos viendo poco a poco.

## Tu misión

En `solucion.cometa` vas a encontrar la función `contar_monedas()`. Su última línea ya devuelve una variable llamada `monedas`, pero esa variable todavía no existe, y por eso el programa muestra un error.

En la parte marcada, crea la variable `monedas` con el valor `10`.

Cuando termines, presiona **Probar** para revisar tu código. Con **Jugar** puedes ver lo que imprime tu programa.

## Lo que necesitas saber

Una variable se crea con `var`, un nombre y un valor.

```cometa
var puntos = 5
```

Una función devuelve lo que hay en su última línea. En este ejercicio esa línea ya está escrita, y solo falta crear la variable que usa.

La palabra `pub` permite que el resto del programa use tu función, así que no la borres.
