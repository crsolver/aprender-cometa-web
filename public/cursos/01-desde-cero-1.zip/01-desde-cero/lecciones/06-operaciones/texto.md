Ya sabes guardar datos en variables. En esta lección vas a hacer cálculos con ellos.

## Operaciones con números

Cometa suma con `+`, resta con `-`, multiplica con `*` y divide con `/`.

```cometa ejecutar
fn inicio()
	imprimir(7 + 3)
	imprimir(7 - 3)
	imprimir(7 * 3)
	imprimir(7 / 2)
```

Mira el último resultado. `7 / 2` da `3` y no `3.5`. Cuando divides dos enteros, el resultado también es un entero y los decimales se descartan. Imagina que repartes 7 monedas entre 2 personas. A cada una le tocan 3, porque una moneda no se puede partir por la mitad.

## El resto de la división

En ese reparto sobró una moneda. El signo `%` calcula lo que sobra de una división, que en matemáticas se llama resto o residuo.

```cometa ejecutar
fn inicio()
	imprimir(7 / 2)
	imprimir(7 % 2)
	imprimir(10 % 5)
```

`7 % 2` da `1` porque sobra una moneda, y `10 % 5` da `0` porque no sobra ninguna. El resto sirve, por ejemplo, para saber si un número es par. Si `numero % 2` da `0`, el número es par.

## Números con decimales

Si alguno de los dos números es un `decimal`, el resultado conserva los decimales.

```cometa ejecutar
fn inicio()
	imprimir(7.0 / 2)
	imprimir(2.5 * 4)
	imprimir(1.5 + 1)
```

## El orden de las operaciones

Igual que en matemáticas, Cometa primero multiplica y divide, y después suma y resta. Con paréntesis puedes indicar cuál operación va primero.

```cometa ejecutar
fn inicio()
	imprimir(2 + 3 * 4)
	imprimir((2 + 3) * 4)
```

## Operaciones con variables

En un programa casi siempre se calcula con variables, y el resultado se guarda en otra variable.

```cometa ejecutar
fn inicio()
	var precio = 12
	var cantidad = 3
	var total = precio * cantidad
	imprimir("Total: ${total} monedas")
```

Dentro de `${}` también puedes escribir una operación completa.

```cometa ejecutar
fn inicio()
	var vida = 80
	imprimir("Con la poción tendrás ${vida + 20} de vida")
```

## Cambiar una variable con una operación

Ya conoces `+=` y `-=`. Las demás operaciones tienen también su forma corta.

```cometa ejecutar
fn inicio()
	var puntos = 10
	puntos += 5
	imprimir(puntos)
	puntos -= 3
	imprimir(puntos)
	puntos *= 2
	imprimir(puntos)
	puntos /= 4
	imprimir(puntos)
```

## Unir cadenas

El signo `+` también sirve para unir dos cadenas, una detrás de la otra.

```cometa ejecutar
fn inicio()
	var nombre = "Ana"
	var saludo = "Hola, " + nombre + "!"
	imprimir(saludo)
```

Fíjate en el espacio que hay después de la coma en `"Hola, "`. Cometa une las cadenas tal como están y no agrega espacios por su cuenta.

Con `+` solo puedes unir cadenas con cadenas. Para mezclar un texto con un número es más cómodo usar `${}`, como has hecho hasta ahora.

## Convertir entre tipos

`"42"` es una cadena, así que no puedes sumarle `1`. Para obtener el número que está escrito dentro del texto usa `a_entero()` o `a_decimal()`.

El texto podría no ser un número, como pasa con `"abc"`. Por eso después de la conversión escribimos `o` seguido de un valor de reserva, que es el que se usa cuando la conversión no se puede hacer.

```cometa ejecutar
fn inicio()
	var texto = "42"
	var numero = texto.a_entero() o 0
	imprimir(numero + 1)
	imprimir("abc".a_entero() o -1)
```

`a_entero()` y `a_decimal()` devuelven un `opcional`, que es un tipo de dato que puede tener un valor o no tenerlo. Lo vamos a estudiar más adelante.

Para convertir en la otra dirección, de número a texto, usa `cadena()` con el número entre los paréntesis.

```cometa ejecutar
fn inicio()
	var puntos = 40
	imprimir("Puntos: " + cadena(puntos))
```

## Pruébalo

Este programa calcula cuántas monedas le tocan a cada amigo y cuántas sobran. Cambia los números y trata de adivinar el resultado antes de correrlo.

```cometa ejecutar
fn inicio()
	var monedas = 17
	var amigos = 5
	imprimir("A cada uno le tocan ${monedas / amigos}")
	imprimir("Sobran ${monedas % amigos}")
```
