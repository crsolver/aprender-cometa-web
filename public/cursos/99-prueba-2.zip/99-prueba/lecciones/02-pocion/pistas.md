Pista de la edición 2. La variable `vida` ya existe, así que no hace falta crear otra. Solo cambia su valor, sin escribir `var`.
---
Para la poción, toma el valor de `vida`, súmale 30 y guarda el resultado en la misma variable.

```cometa
vida = vida + 30
```
---
El golpe se escribe igual, pero restando. Puedes usar la forma corta.

```cometa
vida -= 25
```
