En `flexiones`, recorre los días desde el 1 hasta el último y suma cada número al total.

```cometa
repetir (1..dias + 1) |dia|
	total += dia
```
---
En `tambor` no hace falta el número de la vuelta. Solo hay que repetir y agregar texto.

```cometa
repetir (0..golpes)
	sonido += "pum "
```
---
En `dias_de_descanso`, pon un `si` dentro del ciclo. Un día es múltiplo de 5 cuando el resto de dividirlo entre 5 es cero.

```cometa
repetir (1..dias + 1) |dia|
	si dia % 5 == 0
		descansos += 1
```
---
En `potencia`, el resultado empieza en 1 y se multiplica por la base una vez en cada vuelta.

```cometa
repetir (0..exponente)
	resultado *= base
```
