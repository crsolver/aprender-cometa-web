Un dragón duerme sobre una montaña de cofres. Antes de despertarlo conviene hacer algunas cuentas para saber cuántos golpes aguanta, cuánto oro hay y quién ganaría el combate.

## Tu misión

Completa las tres funciones de `solucion.cometa`.

- `golpes_necesarios(vida, fuerza)` devuelve cuántos golpes hacen falta para dejar al dragón sin vida, es decir, en 0 o menos. Cada golpe le quita `fuerza` puntos de vida. Con 20 de vida y 6 de fuerza hacen falta 4 golpes.
- `oro_sin_maldicion(cofres)` devuelve el total de monedas de los cofres que no están malditos. Los cofres están numerados desde el 1, y cada uno guarda tantas monedas como su número, de modo que el cofre 1 tiene 1 moneda y el cofre 2 tiene 2. Los cofres con un número múltiplo de 3 están malditos y no se deben contar.
- `gana_la_heroina(vida_heroina, vida_dragon, fuerza_heroina, fuerza_dragon)` devuelve `verdadero` si la heroína gana el combate. El combate va por turnos y la heroína golpea primero. Después golpea el dragón, luego ella otra vez, y así siguen hasta que alguno se queda sin vida.

## Lo que necesitas saber

`mientras` repite su bloque siempre que la condición sea verdadera.

```cometa
var agua = 10
var tragos = 0
mientras agua > 0
	agua -= 3
	tragos += 1
```

`continuar` se salta el resto de la vuelta actual y pasa a la siguiente.

```cometa
repetir (1..10) |numero|
	si numero % 2 == 0
		continuar
	imprimir(numero)   // solo los impares
```

`romper` termina el ciclo en ese momento, aunque la condición todavía se cumpla. El programa sigue en la línea que está después del ciclo.

```cometa
var monedas = 0
mientras monedas < 100
	monedas += 30
	si monedas == 60
		romper
```

En la condición de un `mientras` puedes combinar dos preguntas con `&&`. Así puedes decir, por ejemplo, que el ciclo siga mientras las dos tengan vida.

Las vidas y las fuerzas son parámetros, y un parámetro se puede cambiar dentro de la función igual que cualquier variable.
