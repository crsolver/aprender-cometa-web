**Edición 2.** Solo cambiaron este texto y las pistas. El ejercicio no debe aparecer como cambiado.

Tu héroe tiene 50 de vida y acaba de encontrar una poción que le da 30 más. Después lo espera una calavera para darle un golpe.

## Tu misión

En `solucion.cometa` hay una variable llamada `vida` y dos funciones. Fíjate que `vida` está escrita al principio del archivo, fuera de las funciones. A una variable creada así se le llama variable global.

El lugar donde creas una variable decide dónde se puede usar. Una variable creada dentro de una función solo se puede usar en esa función. Una variable global se puede usar en todas las funciones del mismo archivo, y por eso las dos funciones de este ejercicio pueden cambiar `vida`.

- En `beber_pocion()` la vida empieza en 50. Súmale 30.
- En `recibir_golpe()` la vida empieza en 80. Réstale 25.

Presiona **Probar** para revisar tu código y **Jugar** para ver lo que imprime.

## Lo que necesitas saber

Para cambiar una variable escribes su nombre, el signo `=` y el nuevo valor. No se escribe `var` otra vez, porque la variable ya existe.

```cometa
var puntos = 10
puntos = 15
```

El nuevo valor se puede calcular con el valor que la variable ya tenía. La siguiente línea toma lo que vale `puntos`, le suma 5 y guarda el resultado otra vez en `puntos`.

```cometa
puntos = puntos + 5
```

Como esto se usa mucho, existe una forma más corta de escribirlo. La primera de estas líneas suma 5 a `puntos` y la segunda le resta 2.

```cometa
puntos += 5
puntos -= 2
```

Las instrucciones se ejecutan en orden, de arriba hacia abajo. Por eso tu línea va antes de la última, que es la que devuelve el resultado.
