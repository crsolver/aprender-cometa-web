En `precio`, multiplica el metal por 10 y súmale 5. Esa operación es la última línea de la función.

```cometa
metal * 10 + 5
```
---
`grabado` devuelve un texto con el nombre dentro.

```cometa
"Espada de ${nombre}"
```
---
`con_descuento` es una resta.

```cometa
precio - 4
```
---
En `pedido`, llama a las otras dos funciones dentro del texto y pásales los mismos datos que recibiste.

```cometa
"${grabado(nombre)}: ${precio(metal)} monedas"
```
