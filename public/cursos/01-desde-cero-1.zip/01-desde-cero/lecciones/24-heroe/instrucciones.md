El gremio quiere llevar un registro de sus héroes para saber cuánta vida tienen, cuántas monedas llevan y quiénes siguen en pie después de cada misión. Alguien empezó a escribir el tipo `Heroe`, pero lo dejó sin terminar.

## Tu misión

Todo el trabajo se hace en `solucion.cometa`. Empieza por el primer paso, porque el programa va a mostrar un error hasta que lo completes.

### 1. Un campo nuevo

Al tipo `Heroe` le falta el campo de las monedas. Añádelo debajo de `vida`.

```cometa
pub monedas entero
```

### 2. Los métodos

Completa los cuatro métodos del tipo.

- `recibir_golpe(fuerza)` le quita al héroe esa cantidad de vida. La vida nunca puede bajar de 0.
- `esta_vivo()` devuelve `verdadero` si al héroe le queda vida.
- `comprar(precio)` revisa si al héroe le alcanzan las monedas. Si le alcanzan, paga el precio y devuelve `verdadero`. Si no le alcanzan, no cambia nada y devuelve `falso`.
- `descripcion()` devuelve un texto como `"Lira: 80 de vida, 5 monedas"`.

### 3. El equipo

Completa las dos funciones que trabajan con una lista de héroes.

- `vivos(equipo)` devuelve cuántos héroes del equipo siguen vivos.
- `tormenta(equipo, fuerza)` golpea con esa fuerza a todos los héroes del equipo.

## Lo que necesitas saber

Dentro de un método, los campos del héroe se escriben con una arroba, como `@vida` y `@monedas`. Los parámetros se escriben sin arroba.

```cometa
pub fn curar(puntos entero)
	@vida += puntos
	si @vida > 100 @vida = 100
```

Un método que no tiene resultado, como `recibir_golpe`, solo cambia los campos y no devuelve nada. En la plantilla esos métodos tienen un `retornar` de relleno. Bórralo cuando escribas tu código.

Una lista de héroes se recorre como cualquier otra lista, y con cada héroe puedes llamar a sus métodos.

```cometa
repetir (equipo) |heroe|
	heroe.curar(10)
```

En este archivo los campos y los métodos llevan `pub`, igual que las funciones, para que el resto del programa pueda usarlos.
