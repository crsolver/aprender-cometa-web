La herrera del pueblo forja espadas a la medida y quiere un programa que le prepare los pedidos. Las funciones ya tienen nombre, parámetros y tipo de resultado, pero por dentro están vacías y devuelven `0` o un texto vacío.

## Tu misión

Completa las cuatro funciones de `solucion.cometa`.

- `precio(metal)` devuelve lo que cuesta una espada. Se cobran 10 monedas por cada pieza de metal, más 5 monedas por el trabajo. Con 3 piezas son 35 monedas.
- `grabado(nombre)` devuelve el texto que se graba en la hoja, como `"Espada de Lira"`.
- `con_descuento(precio)` devuelve el precio con 4 monedas menos, que es el descuento para los clientes del gremio.
- `pedido(nombre, metal)` devuelve el texto del pedido completo, como `"Espada de Lira: 35 monedas"`. Para no repetir las cuentas, llama a `grabado` y a `precio` desde esta función.

En cada función, borra el valor de relleno de la última línea (`0` o `""`) y escribe el tuyo.

## Lo que necesitas saber

Una función devuelve el valor de su última línea.

```cometa
pub fn area(ancho entero, alto entero) entero
	ancho * alto
```

Puedes llamar a una función desde otra y usar lo que devuelve como un valor más.

```cometa
pub fn area_de_dos(ancho entero, alto entero) entero
	area(ancho, alto) * 2
```

También puedes poner una llamada dentro de un texto.

```cometa
"El área es ${area(3, 4)}"
```
