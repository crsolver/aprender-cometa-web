Antes de estudiar cada tema con calma, vamos a dar un recorrido rápido por las ideas principales. Si algo no te queda claro aquí, no te preocupes, porque cada una de estas ideas tiene su propia lección más adelante.

Todo programa trabaja con datos. A veces los lee, a veces los modifica y a veces los crea. Para poder usarlos, la computadora los guarda en su memoria. Cuando el valor de un dato puede cambiar mientras el programa funciona, lo llamamos variable. En un juego, por ejemplo, necesitamos guardar los puntos de vida del jugador, que bajan cuando recibe daño y suben cuando toma una poción.

## ¿Qué es una variable?

Imagina que una variable es una caja con una etiqueta. La etiqueta es el nombre que tú le pones, y dentro de la caja guardas un valor.

Para crear una variable escribe `var`, luego el nombre que quieres darle y después el signo `=` con el valor que va a guardar.

```cometa
var vida = 80
```

## ¿Cómo cambio el valor de una variable?

Como su nombre lo dice, una variable puede variar. Para cambiarla escribes su nombre, el signo `=` y el nuevo valor. Esta vez no se escribe `var`, porque la caja ya existe.

```cometa
vida = 100
```

Ahora la caja `vida` guarda un 100. Podemos imaginar que el jugador tomó una poción.

## ¿Qué es una constante?

Algunos datos no deben cambiar nunca, como la cantidad de días que tiene una semana. Para esos datos usa `const` en lugar de `var`. Si más adelante intentas cambiar su valor por accidente, Cometa te avisa con un error.

```cometa
const dias_por_semana = 7
```

## Comentarios

A veces conviene dejar notas dentro del código para explicar algo o para recordarlo después. Esas notas se llaman comentarios y empiezan con dos barras inclinadas. Cometa ignora lo que está después de las barras en esa línea, así que un comentario no cambia lo que hace el programa.

```cometa
// Esto es un comentario
```

## Tipos

Los datos pueden ser de distintos tipos. Si guardamos la información de una persona, su edad es un número y su nombre es un texto. En Cometa un número sin decimales es de tipo `entero`. Un texto es de tipo `cadena`, que es la forma corta de decir "cadena de caracteres", y siempre se escribe entre comillas.

```cometa
var edad = 12 // entero
var nombre = "María" // cadena
```

Cometa reconoce el tipo de una variable por el valor que le das. Si quieres, también puedes escribir el tipo después del nombre.

```cometa
var edad entero = 12
var nombre cadena = "María"
```

Una variable solo puede guardar valores de su tipo.

```cometa
edad = "hola" // error: "hola" no es un entero
```

## ¿Cómo mostrar resultados en la consola?

La consola es el espacio donde aparece el texto que produce tu programa. Para mostrar ahí un dato o el valor de una variable se usa `imprimir`, con el dato entre paréntesis.

```cometa
imprimir(nombre) // María
```

## ¿Qué es una función?

Una función es un grupo de instrucciones que cumple una tarea y tiene un nombre. `imprimir` es una función que ya viene con Cometa, y su tarea es mostrar en la consola lo que pongas entre los paréntesis.

También puedes crear tus propias funciones. Escribe `fn`, el nombre que quieras y un par de paréntesis.

```cometa
fn saludar()
	imprimir("¡Hola!")
```

Las instrucciones de una función se escriben debajo de su nombre, cada una con un Tab (tabulador) al principio. Ese espacio le indica a Cometa que la línea pertenece a la función.

Todos los programas de Cometa empiezan en una función llamada `inicio`. Cuando corres tu programa, Cometa busca esa función y ejecuta sus instrucciones.

```cometa ejecutar
fn saludar()
	imprimir("¡Hola!")

fn inicio()
	saludar()
```

## Pruébalo

Cambia el valor guardado en `vida` y corre el programa para ver qué se imprime.

```cometa ejecutar
fn inicio()
	var vida = 0
	imprimir(vida)
```

En este otro programa, cambia el `8` por una cadena de texto, como `"hola"`, y córrelo. Vas a ver el error que muestra Cometa cuando el valor no es del tipo de la variable.

```cometa ejecutar
fn inicio()
	var edad entero = 8
	imprimir(edad)
```
