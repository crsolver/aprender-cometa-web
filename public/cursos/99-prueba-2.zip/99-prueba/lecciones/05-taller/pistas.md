Esta es la primera función completa. Fíjate en el tabulador de la segunda línea.

```cometa
pub fn triple(numero entero) entero
	numero * 3
```
---
`perimetro` recibe dos parámetros y devuelve un entero. Un rectángulo tiene dos lados que miden `ancho` y dos que miden `alto`.

```cometa
pub fn perimetro(ancho entero, alto entero) entero
	ancho * 2 + alto * 2
```
---
`bienvenida` recibe una cadena y devuelve otra cadena.

```cometa
pub fn bienvenida(nombre cadena) cadena
	"¡Bienvenida al taller, ${nombre}!"
```
---
Si el error dice que un nombre no existe, revisa que la función se llame exactamente así y que empiece con `pub fn`.
