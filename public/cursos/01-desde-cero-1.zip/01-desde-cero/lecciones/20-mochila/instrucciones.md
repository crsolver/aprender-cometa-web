Antes de salir de viaje hay que revisar la mochila. Como la mochila es una lista, puedes recorrerla para saber cuánto pesa, cuál es el objeto más pesado y qué conviene dejar en casa.

## Tu misión

Completa las cinco funciones de `solucion.cometa`.

- `peso_total(pesos)` recibe la lista con el peso de cada objeto y devuelve la suma de todos.
- `mas_pesado(pesos)` devuelve el peso más grande de la lista. Si la lista está vacía, devuelve `0`.
- `cuantas(objetos, buscado)` devuelve cuántas veces aparece `buscado` en la lista de objetos. En `["poción", "llave", "poción"]`, la `"poción"` aparece 2 veces.
- `ligeros(pesos, limite)` devuelve una lista nueva que solo tiene los pesos menores o iguales al límite.
- `primero(objetos)` devuelve el primer objeto de la lista, o `"nada"` si la mochila está vacía.

## Lo que necesitas saber

Esta función recorre una lista y acumula un resultado.

```cometa
pub fn sumar(numeros [entero]) entero
	var total = 0
	repetir (numeros) |numero|
		total += numero
	total
```

Para armar una lista nueva, empieza con una lista vacía y usa `agregar`. A una lista vacía hay que escribirle el tipo.

```cometa
var pares [entero] = []
repetir (numeros) |numero|
	si numero % 2 == 0
		pares.agregar(numero)
```

Pedir un índice que no existe detiene el programa. Con `obtener` eso no pasa, porque después de `o` escribes el valor que se usa cuando en esa posición no hay nada.

```cometa
var ultimo = nombres.obtener(5) o "nadie"
```
