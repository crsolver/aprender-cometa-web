Una heroína tiene nombre, vida y monedas. Podrías guardar cada dato en una variable distinta, pero cuando haya dos heroínas vas a tener `nombre1`, `vida1`, `nombre2`, `vida2` y otras variables parecidas, y será fácil confundirlas. Es más cómodo que los datos de una misma heroína estén juntos.

Ya conoces varios de los tipos que vienen con Cometa, como `entero` y `cadena`. Cometa también te permite crear tus propios tipos.

## Crear un tipo

Con la palabra `tipo` creas un tipo nuevo y dices cuáles datos tiene. Cada uno de esos datos se llama campo, y lleva un nombre y un tipo.

```cometa ejecutar
tipo Heroe
	nombre cadena
	vida entero
	monedas entero

fn inicio()
	var lira = Heroe {nombre: "Lira", vida: 100, monedas: 5}
	imprimir(lira)
```

El tipo se escribe fuera de las funciones. Por costumbre su nombre empieza con mayúscula, para distinguirlo de las variables.

`tipo Heroe` funciona como un molde, y por sí solo todavía no crea ninguna heroína. Para crear un valor se escribe el nombre del tipo y después los campos entre llaves, como en `Heroe {nombre: "Lira", vida: 100, monedas: 5}`.

## Leer y cambiar los campos

Para usar un campo se escribe el nombre de la variable, un punto y el nombre del campo. Un campo se puede leer y cambiar igual que cualquier variable.

```cometa ejecutar
tipo Heroe
	nombre cadena
	vida entero
	monedas entero

fn inicio()
	var lira = Heroe {nombre: "Lira", vida: 100, monedas: 5}
	imprimir(lira.nombre)
	lira.vida -= 30
	lira.monedas += 10
	imprimir("${lira.nombre} tiene ${lira.vida} de vida y ${lira.monedas} monedas")
```

## Valores iniciales

Si al crear un valor no le das un valor a un campo, Cometa le pone un valor inicial. Los números empiezan en `0`, las cadenas empiezan vacías (`""`) y los bool empiezan en `falso`.

Cuando quieres que un campo empiece con otro valor, escríbelo en el tipo con el signo `=`.

```cometa ejecutar
tipo Heroe
	nombre cadena // valor inicial: ""
	vida entero = 100
	monedas entero // valor inicial: 0

fn inicio()
	var lira = Heroe {nombre: "Lira"} // vida empieza en 100
	var bruno = Heroe {nombre: "Bruno", vida: 60} // vida es 60 en lugar de 100
	imprimir(lira)
	imprimir(bruno)
```

## Funciones que reciben tu tipo

Un tipo creado por ti se usa igual que los demás. Puede ser el tipo de un parámetro, el del resultado de una función o el de los elementos de una lista.

```cometa ejecutar
tipo Heroe
	nombre cadena
	vida entero = 100

fn presentar(heroe Heroe) cadena
	"${heroe.nombre} (${heroe.vida} de vida)"

fn inicio()
	var lira = Heroe {nombre: "Lira"}
	imprimir(presentar(lira))
```

## Métodos

Una función que se escribe dentro de un tipo, con un tabulador, se llama método. Un método pertenece a ese tipo y se llama con un punto, como en `lira.recibir_golpe(70)`.

Dentro de un método, los campos se escriben con una arroba al principio. La arroba representa al valor con el que se llamó el método, de modo que `@vida` es la vida de esa heroína en particular.

```cometa ejecutar
tipo Heroe
	nombre cadena
	vida entero = 100

	fn recibir_golpe(fuerza entero)
		@vida -= fuerza

	fn esta_vivo() bool
		@vida > 0

fn inicio()
	var lira = Heroe {nombre: "Lira"}
	lira.recibir_golpe(70)
	imprimir(lira.vida)
	imprimir(lira.esta_vivo())
	lira.recibir_golpe(70)
	imprimir(lira.esta_vivo())
```

Ya has usado métodos en las lecciones anteriores. `lista.agregar()` es un método de las listas y `texto.mayusculas()` es un método de las cadenas.

Un método puede llamar a otro método del mismo valor, también con la arroba, como en `@esta_vivo()`.

## El mismo valor y no una copia

Cuando le pasas a una función un valor de un tipo creado por ti, la función recibe ese mismo valor y no una copia. Si la función lo cambia, el cambio se ve también fuera de ella.

```cometa ejecutar
tipo Heroe
	nombre cadena
	vida entero = 100

fn envenenar(heroe Heroe)
	heroe.vida -= 40

fn inicio()
	var lira = Heroe {nombre: "Lira"}
	envenenar(lira)
	imprimir(lira.vida)
```

En un juego esto resulta muy útil, porque las funciones que mueven al personaje o le quitan vida necesitan cambiar al personaje del juego y no a una copia.

## Listas de tus tipos

Una lista de `Heroe` se recorre igual que una lista de números. Dentro del ciclo puedes leer o cambiar los campos de cada elemento.

```cometa ejecutar
tipo Heroe
	nombre cadena
	vida entero = 100

fn inicio()
	var equipo = [
		Heroe {nombre: "Lira", vida: 80},
		Heroe {nombre: "Bruno", vida: 35},
		Heroe {nombre: "Noa"},
	]
	repetir (equipo) |heroe|
		heroe.vida += 10
	repetir (equipo) |heroe|
		imprimir("${heroe.nombre}: ${heroe.vida}")
```

El tipo de esa lista se escribe `[Heroe]`. Si lo escribes al crear la lista, ya no hace falta repetir `Heroe` en cada elemento.

```cometa
tipo Heroe
	nombre cadena
	vida entero = 100

fn inicio()
	var equipo [Heroe] = [
		{nombre: "Lira", vida: 80},
		{nombre: "Bruno", vida: 35},
		{nombre: "Noa"},
	]
```

## Pruébalo

Añade al tipo `Mascota` un campo `edad` de tipo `entero` y un método `crecer()` que le sume 1. Después úsalos en `inicio`.

```cometa ejecutar
tipo Mascota
	nombre cadena
	energia entero = 10

	fn jugar()
		@energia -= 3

	fn descansar()
		@energia += 5

fn inicio()
	var michi = Mascota {nombre: "Michi"}
	michi.jugar()
	michi.jugar()
	michi.descansar()
	imprimir("${michi.nombre} tiene ${michi.energia} de energía")
```
