Una nueva aventurera llegó al gremio y hay que llenar su ficha. Cada dato de la ficha es de un tipo distinto.

## Tu misión

En `solucion.cometa`, dentro de la función `ficha()`, crea cuatro variables en la parte marcada.

- `nombre` es una cadena con el valor `"Lira"`.
- `nivel` es un entero con el valor `3`.
- `altura` es un decimal con el valor `1.6`.
- `es_maga` es un bool con el valor `verdadero`.

La última línea de la función ya usa esas cuatro variables para armar la ficha. Mientras no existan, el programa va a mostrar un error, y eso es normal.

## Lo que necesitas saber

Aquí tienes un ejemplo de cada uno de los cuatro tipos básicos.

```cometa
var ciudad = "Puntarenas"    // cadena: texto entre comillas
var habitantes = 500         // entero: número sin decimales
var temperatura = 28.5       // decimal: número con punto
var tiene_playa = verdadero  // bool: verdadero o falso
```

Cometa revisa los tipos. Si le das a `nivel` el texto `"3"` en lugar del número `3`, te avisará con un error, porque la ficha espera un entero. Lee el mensaje con calma y fíjate en el número de línea que indica.

Los nombres deben quedar escritos exactamente como se piden, en minúsculas y con guion bajo, como `es_maga`.
