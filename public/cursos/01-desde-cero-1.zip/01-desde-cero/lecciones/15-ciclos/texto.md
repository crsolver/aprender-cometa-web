Imagina que quieres mostrar en la consola la tabla del 7. Con lo que ya sabes puedes hacerlo escribiendo diez líneas de `imprimir`, una por cada multiplicación, pero si después necesitas la tabla del 8 tendrías que corregir las diez líneas una por una.

## Repetir varias veces

Con `repetir` puedes escribir una instrucción una sola vez y pedirle a Cometa que la ejecute varias veces. En este ejemplo el saludo se imprime tres veces.

```cometa ejecutar
fn inicio()
	repetir (0..3)
		imprimir("¡Hola!")
```

Lo que está entre paréntesis se llama rango y le dice a Cometa en qué número empieza a contar y en cuál se detiene. `0..3` se lee "de 0 a 3". La línea de `imprimir` lleva un tabulador más que `repetir` porque así Cometa sabe cuál es la línea que debe repetir. A cada repetición se le llama una vuelta, y a esta forma de repetir instrucciones se le llama ciclo.

Si cuentas las vueltas verás que Cometa usa el 0, el 1 y el 2, pero no el 3. El primer número del rango se incluye y el último no. Pasa lo mismo con una clase que va de 7 a 9. Esa clase dura dos horas, que son la hora que empieza a las 7 y la hora que empieza a las 8. A las 9 la clase ya terminó, así que esa hora no cuenta.

## Saber en cuál vuelta vas

Cuando necesitas saber por cuál número va la cuenta, puedes escribir un nombre entre barras verticales después del rango. Cometa crea una variable con ese nombre y en cada vuelta guarda en ella el número que corresponde.

```cometa ejecutar
fn inicio()
	repetir (1..11) |numero|
		imprimir("7 x ${numero} = ${7 * numero}")
```

Ahora la tabla del 7 ocupa dos líneas en lugar de diez. El rango es `1..11` porque el 11 no se incluye, así que la cuenta llega hasta el 10. Cambia los dos 7 por un 8 en la línea de `imprimir` y corre el programa de nuevo para ver la tabla del 8.

El nombre entre las barras lo eliges tú. Muchas personas que programan usan la letra `i` cuando el número solo sirve para contar.

```cometa ejecutar
fn inicio()
	repetir (0..5) |i|
		imprimir(i)
```

## Rangos con variables

Los dos números del rango pueden ser variables, parámetros u operaciones. En este ejemplo el rango termina en `limite + 1` para que el último número impreso sea el límite.

```cometa ejecutar
fn contar_hasta(limite entero)
	repetir (1..limite + 1) |numero|
		imprimir(numero)

fn inicio()
	contar_hasta(4)
```

## Contar hacia atrás

Un rango siempre cuenta hacia adelante. Para contar hacia atrás se agrega `paso = -1` después del rango, y así cada vuelta resta uno en lugar de sumarlo. La regla es la misma, de modo que el primer número se incluye y el último no.

```cometa ejecutar
fn inicio()
	repetir (3..0, paso = -1) |i|
		imprimir(i)
	imprimir("¡Despegue!")
```

## Acumular un resultado

Los ciclos se usan mucho para ir armando un resultado poco a poco. Se crea una variable antes del ciclo, se cambia en cada vuelta y se usa cuando el ciclo termina. El siguiente programa suma los números del 1 al 5 de esa forma.

```cometa ejecutar
fn inicio()
	var suma = 0
	repetir (1..6) |numero|
		suma += numero
	imprimir(suma)
```

Sigue el programa paso a paso. `suma` empieza en 0. En la primera vuelta pasa a valer 1, luego 3, después 6, luego 10 y al final 15.

La variable se crea fuera del ciclo. Si la crearas dentro, volvería a empezar en 0 en cada vuelta.

De la misma forma puedes armar un texto.

```cometa ejecutar
fn inicio()
	var estrellas = ""
	repetir (0..5)
		estrellas += "*"
	imprimir(estrellas)
```

## Decidir dentro de un ciclo

Dentro de un ciclo puedes escribir un `si`. Como está dentro del ciclo lleva un tabulador más, y las líneas que pertenecen al `si` llevan otro.

```cometa ejecutar
fn inicio()
	var pares = 0
	repetir (1..11) |numero|
		si numero % 2 == 0
			imprimir("${numero} es par")
			pares += 1
	imprimir("Hay ${pares} números pares")
```

Los tabuladores le indican a Cometa cuáles líneas pertenecen al `si` y cuáles al ciclo. La última línea está fuera del ciclo, y por eso se ejecuta una sola vez, al final.

## Ciclos en funciones

Una función puede usar un ciclo para calcular su resultado. La última línea de la función, que está fuera del ciclo, es el valor que se devuelve.

```cometa ejecutar
fn sumar_hasta(limite entero) entero
	var suma = 0
	repetir (1..limite + 1) |numero|
		suma += numero
	suma

fn inicio()
	imprimir(sumar_hasta(5))
	imprimir(sumar_hasta(100))
```

## Pruébalo

En este programa el número de la tabla está guardado en una variable. Cámbialo para ver la tabla de otro número, y después cambia el rango para que la tabla llegue hasta el 12.

```cometa ejecutar
fn inicio()
	var tabla = 7
	repetir (1..11) |numero|
		imprimir("${tabla} x ${numero} = ${tabla * numero}")
```
