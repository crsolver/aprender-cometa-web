Los nombres, los mensajes y los diálogos de un juego son datos de tipo `cadena`. En las lecciones anteriores ya creaste cadenas, las uniste y las imprimiste. En esta lección vas a conocer otras operaciones que se pueden hacer con ellas.

## Las cadenas tienen herramientas

Las listas tienen `longitud()` y `agregar()`, y las cadenas tienen también sus propias herramientas. Se usan de la misma forma. Primero va la cadena, después un punto y luego el nombre de la herramienta con paréntesis.

```cometa ejecutar
fn inicio()
	var nombre = "Cometa"
	imprimir(nombre.longitud())
	imprimir(nombre.mayusculas())
	imprimir(nombre.minusculas())
```

`longitud()` cuenta los caracteres de la cadena, y los espacios también cuentan. `mayusculas()` devuelve el texto en mayúsculas y `minusculas()` lo devuelve en minúsculas.

## Una cadena no cambia

Estas herramientas dejan la cadena original como estaba y devuelven una cadena nueva. Conviene tenerlo presente, porque olvidarlo es una causa frecuente de errores.

```cometa ejecutar
fn inicio()
	var nombre = "Cometa"
	nombre.mayusculas()
	imprimir(nombre)
	nombre = nombre.mayusculas()
	imprimir(nombre)
```

La primera vez se imprime `Cometa`, porque el resultado de `mayusculas()` no se guardó en ninguna parte y se perdió. Para conservarlo tienes que guardarlo, ya sea en la misma variable o en otra.

## Preguntarle cosas a un texto

Estas herramientas responden con un bool.

```cometa ejecutar
fn inicio()
	var frase = "El dragón duerme en la cueva"
	imprimir(frase.contiene("dragón"))
	imprimir(frase.contiene("unicornio"))
	imprimir(frase.empieza_con("El"))
	imprimir(frase.termina_con("cueva"))
```

Para Cometa, `"El"` y `"el"` son textos distintos, porque una letra mayúscula y su minúscula no son iguales. Si quieres comparar dos textos sin que eso afecte, convierte primero el texto a minúsculas.

```cometa ejecutar
fn inicio()
	var respuesta = "SÍ"
	si respuesta.minusculas() == "sí"
		imprimir("Has dicho que sí")
```

## Limpiar y reemplazar

`recortar()` quita los espacios que hay al principio y al final. `reemplazar` cambia un texto por otro en todos los lugares donde aparece.

```cometa ejecutar
fn inicio()
	var nombre = "   Lira   "
	imprimir("[${nombre.recortar()}]")
	var frase = "Me gusta el brócoli"
	imprimir(frase.reemplazar("brócoli", "chocolate"))
```

Como cada herramienta devuelve una cadena, puedes usar varias seguidas en una misma línea.

```cometa ejecutar
fn inicio()
	var nombre = "   lira   "
	imprimir(nombre.recortar().mayusculas())
```

## Partir una cadena en trozos

`dividir` corta una cadena cada vez que encuentra el separador que le indiques y devuelve una lista con los trozos.

```cometa ejecutar
fn inicio()
	var frase = "espada escudo poción"
	var palabras = frase.dividir(" ")
	imprimir(palabras)
	imprimir(palabras.longitud())
	imprimir(palabras[0])
```

El resultado es una lista como las que ya conoces, así que puedes recorrerla con `repetir`.

## Recorrer las letras

Si a `dividir` le das una cadena vacía como separador, corta entre cada carácter. El resultado es una lista con las letras, que puedes recorrer una por una.

```cometa ejecutar
fn inicio()
	var palabra = "hola"
	repetir (palabra.dividir("")) |letra|
		imprimir(letra)
```

Al recorrer las letras puedes contarlas, buscar una en particular o construir otra cadena. Este programa cuenta cuántas veces aparece la letra `a`.

```cometa ejecutar
fn inicio()
	var palabra = "banana"
	var veces = 0
	repetir (palabra.dividir("")) |letra|
		si letra == "a"
			veces += 1
	imprimir(veces)
```

## Construir una cadena letra por letra

Un texto también se puede acumular. Empiezas con una cadena vacía y le vas añadiendo trozos en cada vuelta. Este ejemplo pone un guion después de cada letra.

```cometa ejecutar
fn inicio()
	var palabra = "sol"
	var resultado = ""
	repetir (palabra.dividir("")) |letra|
		resultado += letra + "-"
	imprimir(resultado)
```

El orden en que unes las cadenas cambia el resultado. Con `resultado + letra`, la letra nueva queda al final. Con `letra + resultado`, la letra nueva queda antes de las anteriores.

## Leer un carácter

Igual que en las listas, `obtener` lee el carácter que está en una posición, contando desde 0. También necesita un `o` con el valor que se usa cuando esa posición no existe.

```cometa ejecutar
fn inicio()
	var nombre = "Lira"
	imprimir(nombre.obtener(0) o "?")
	imprimir(nombre.obtener(20) o "?")
```

## Pruébalo

Este programa cuenta las palabras de una frase. Cambia la frase y revisa que el resultado sea correcto.

```cometa ejecutar
fn inicio()
	var frase = "Noble patria tu hermosa bandera"
	var palabras = frase.dividir(" ")
	imprimir("La frase tiene ${palabras.longitud()} palabras")
	imprimir("Y ${frase.longitud()} caracteres")
```
