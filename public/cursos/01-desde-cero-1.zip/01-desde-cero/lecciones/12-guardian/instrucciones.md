Un guardián vigila el puente del río, pero es nuevo en el trabajo. Deja pasar a todas las personas, les cobra lo mismo y saluda igual de día que de noche. Enséñale a decidir.

## Tu misión

Completa las cuatro funciones de `solucion.cometa`.

- `puede_cruzar(monedas)` devuelve `verdadero` si el viajero tiene 5 monedas o más.
- `peaje(edad)` devuelve lo que paga el viajero según su edad. Los menores de 12 años no pagan (`0`), de 12 a 17 años pagan `3` monedas, y desde los 18 años pagan `5`.
- `saludo(es_de_noche)` devuelve `"Buenas noches"` si es de noche y `"Buenos días"` si no lo es.
- `mas_rapido(caballo, burro)` recibe la velocidad de dos animales y devuelve la mayor.

## Lo que necesitas saber

Una comparación ya es un `bool`, así que puede ser el resultado de una función.

```cometa
pub fn es_adulto(edad entero) bool
	edad >= 18
```

`si` elige entre dos caminos, y con `osi` puedes agregar más. Cuando el `si` produce un valor, necesita un `sino`.

```cometa
pub fn talla(altura entero) cadena
	si altura < 120 "pequeña"
	osi altura < 160 "mediana"
	sino "grande"
```

Las condiciones se revisan en orden y se toma el camino de la primera que se cumple.

Un parámetro de tipo `bool` ya es una condición, y no hace falta compararlo con nada.

```cometa
si esta_lloviendo "paraguas"
sino "gorra"
```
