Las variables que has usado hasta ahora guardan un solo dato. Muchas veces un programa necesita guardar una gran cantidad de datos parecidos, como los objetos que hay en una mochila o los enemigos de un videojuego. Podrías crear una variable para cada objeto, pero durante el juego unos objetos se gastan y otros se agregan, y no sabrías cuántas variables vas a necesitar.

## Crear una lista

Una lista es una fila de valores guardados en una sola variable. Se escribe entre corchetes, con los valores separados por comas.

```cometa ejecutar
fn inicio()
	var mochila = ["espada", "escudo", "poción"]
	var puntos = [10, 25, 8]
	imprimir(mochila)
	imprimir(puntos)
```

Todos los elementos de una lista son del mismo tipo. Puedes tener una lista de cadenas o una lista de enteros, pero no una lista que mezcle cadenas con enteros.

## Leer un elemento

Cada elemento tiene una posición dentro de la lista, y al número de esa posición se le llama índice. Para leer un elemento, escribe su índice entre corchetes después del nombre de la lista.

```cometa ejecutar
fn inicio()
	var mochila = ["espada", "escudo", "poción"]
	imprimir(mochila[0])
	imprimir(mochila[2])
```

Los índices empiezan en 0. El primer elemento es el `[0]`, el segundo es el `[1]`, y así con los demás. Es la misma forma de contar que viste en los rangos, y es normal que al principio confunda.

## Cuántos elementos hay

`longitud()` dice cuántos elementos tiene la lista. Se escribe después del nombre de la lista, con un punto en medio.

```cometa ejecutar
fn inicio()
	var mochila = ["espada", "escudo", "poción"]
	imprimir(mochila.longitud())
```

Como los índices empiezan en 0, el último elemento de una lista de 3 elementos está en el índice 2. El índice del último elemento siempre es uno menos que la longitud.

## Cambiar y agregar

Un elemento se cambia igual que una variable, indicando su índice. Para añadir un elemento nuevo al final de la lista se usa `agregar`.

```cometa ejecutar
fn inicio()
	var mochila = ["espada", "escudo"]
	mochila[0] = "hacha"
	mochila.agregar("antorcha")
	imprimir(mochila)
	imprimir(mochila.longitud())
```

## Recorrer una lista

`repetir` también puede recorrer una lista. Entre los paréntesis se escribe la lista en lugar de un rango, y en cada vuelta la variable que está entre las barras guarda el siguiente elemento.

```cometa ejecutar
fn inicio()
	var mochila = ["espada", "escudo", "poción"]
	repetir (mochila) |objeto| // por cada objeto en la mochila
		imprimir("Llevas: ${objeto}")
```

Con esta forma no hace falta usar índices ni conocer la longitud. El ciclo da una vuelta por cada elemento, sin importar si la lista tiene tres elementos o tres mil.

Si además necesitas el índice, agrega una segunda variable entre las barras.

```cometa ejecutar
fn inicio()
	var amigos = ["Ana", "Luis", "Marta"]
	repetir (amigos) |nombre, i|
		imprimir("${i + 1}. ${nombre}")
```

## Acumular con una lista

Puedes acumular un resultado igual que con los rangos. Este programa suma todos los números de una lista.

```cometa ejecutar
fn inicio()
	var precios = [12, 30, 8]
	var total = 0
	repetir (precios) |precio|
		total += precio
	imprimir(total)
```

Con un `si` dentro del ciclo puedes contar solo los elementos que cumplen una condición, o buscar el mayor de todos.

```cometa ejecutar
fn inicio()
	var notas = [70, 45, 90, 55, 100]
	var mejor = 0
	repetir (notas) |nota|
		si nota > mejor
			mejor = nota
	imprimir("La mejor nota es ${mejor}")
```

## Empezar con una lista vacía

A veces la lista empieza vacía y se va llenando durante el programa. Como no tiene elementos, Cometa no puede reconocer su tipo, y por eso hay que escribirlo. El tipo de una lista es el tipo de sus elementos entre corchetes.

```cometa ejecutar
fn inicio()
	var pares [entero] = []
	repetir (1..11) |numero|
		si numero % 2 == 0
			pares.agregar(numero)
	imprimir(pares)
```

`[entero]` quiere decir "lista de enteros", y `[cadena]` quiere decir "lista de cadenas". El tipo se escribe de la misma forma cuando una función recibe o devuelve una lista.

```cometa ejecutar
fn sumar(numeros [entero]) entero
	var total = 0
	repetir (numeros) |numero|
		total += numero
	total

fn inicio()
	imprimir(sumar([1, 2, 3]))
	imprimir(sumar([10, 20]))
```

## Preguntar si algo está en la lista

`contiene` revisa si un valor está en la lista y responde con un bool.

```cometa ejecutar
fn inicio()
	var mochila = ["espada", "escudo"]
	imprimir(mochila.contiene("escudo"))
	imprimir(mochila.contiene("llave"))
```

## Cuando el índice no existe

Si pides `mochila[10]` y la mochila solo tiene tres objetos, el programa se detiene con un error. Cuando no estás seguro de que un índice exista, usa `obtener`, y con `o` indica cuál valor quieres recibir si en esa posición no hay nada.

```cometa ejecutar
fn inicio()
	var mochila = ["espada", "escudo"]
	imprimir(mochila.obtener(1) o "nada")
	imprimir(mochila.obtener(10) o "nada")
```

Ya habías usado `o` al convertir textos en números, y aquí cumple la misma función. Si el valor existe se usa ese valor, y si no existe se usa el que escribiste después de `o`.

## Pruébalo

Agrega más objetos a la mochila con distintos pesos y observa cómo cambia el resultado. Después cambia el límite de peso.

```cometa ejecutar
fn inicio()
	var pesos = [4, 7, 2]
	var limite = 15
	var total = 0
	repetir (pesos) |peso|
		total += peso
	si total > limite
		imprimir("Demasiado peso: ${total}")
	sino
		imprimir("Puedes cargar con todo: ${total}")
```
