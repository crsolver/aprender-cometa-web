Hasta ahora tus programas han hecho siempre lo mismo, una línea después de la otra. Un juego necesita además tomar decisiones. Si la vida del jugador llega a cero, la partida se acaba, y si el jugador tiene la llave, la puerta se abre. En esta lección vas a aprender a escribir esas decisiones.

## Comparar

Toda decisión empieza con una pregunta, y en Cometa las preguntas se hacen comparando dos valores. La respuesta es un valor de tipo `bool`, que solo puede ser `verdadero` o `falso`.

El siguiente programa hace tres preguntas sobre la variable `vida`. Córrelo para ver las respuestas.

```cometa ejecutar
fn inicio()
	var vida = 30
	imprimir(vida > 0)
	imprimir(vida == 100)
	imprimir(vida != 100)
```

Estas son las comparaciones que puedes usar.

- `==` igual a
- `!=` distinto de
- `<` menor que
- `>` mayor que
- `<=` menor o igual que
- `>=` mayor o igual que

Ten cuidado de no confundir `=` con `==`. Un solo signo `=` guarda un valor en una variable. El signo doble `==` pregunta si dos valores son iguales.

También puedes comparar cadenas y guardar la respuesta en una variable.

```cometa ejecutar
fn inicio()
	var palabra = "cometa"
	var acerto = palabra == "cometa"
	imprimir(acerto)
```

## Decidir con si

Con `si` puedes indicar que algunas líneas se ejecuten únicamente cuando una condición es verdadera. Esas líneas se escriben debajo, con un tabulador más, igual que el contenido de una función.

```cometa ejecutar
fn inicio()
	var vida = 0
	si vida == 0
		imprimir("Fin de la partida")
	imprimir("Gracias por jugar")
```

Cambia la vida por `50` y corre el programa otra vez. El primer mensaje ya no aparece, porque la condición no se cumple. El segundo aparece siempre, porque está fuera del `si`.

## Qué hacer cuando no se cumple

Con `sino` indicas lo que debe pasar cuando la condición es falsa. El programa tiene entonces dos caminos y siempre toma uno de ellos.

```cometa ejecutar
fn inicio()
	var monedas = 3
	si monedas >= 5
		imprimir("Compras la poción")
	sino
		imprimir("No te alcanza")
```

## Más de dos caminos

Cuando hay más de dos posibilidades, puedes agregar otra pregunta con `osi`. Cometa revisa las condiciones en orden, de arriba hacia abajo, y toma el camino de la primera que se cumple.

```cometa ejecutar
fn inicio()
	var nota = 75
	si nota >= 90
		imprimir("Excelente")
	osi nota >= 70
		imprimir("Aprobado")
	sino
		imprimir("A repasar")
```

El orden en que escribes las condiciones cambia el resultado. Con una nota de 95 se cumplen las dos primeras, pero solo se imprime "Excelente", porque esa condición está antes.

## Decisiones cortas en una línea

Si lo que hay que hacer es una sola instrucción, se puede escribir en la misma línea del `si`.

```cometa ejecutar
fn inicio()
	var vida = 120
	si vida > 100 vida = 100
	imprimir(vida)
```

## Un si que produce un valor

Muchas veces una decisión sirve para elegir un valor. En una función que devuelve un resultado, cada camino del `si` puede terminar en un valor, y la función devuelve el del camino que se tomó.

```cometa ejecutar
fn mayor(a entero, b entero) entero
	si a > b
		a
	sino
		b

fn inicio()
	imprimir(mayor(3, 8))
	imprimir(mayor(10, 2))
```

Cuando un `si` produce un valor, el `sino` es obligatorio, porque la función tiene que devolver algo en todos los casos.

La forma corta también funciona aquí.

```cometa ejecutar
fn describir(numero entero) cadena
	si numero < 0 "negativo"
	osi numero == 0 "cero"
	sino "positivo"

fn inicio()
	imprimir(describir(-4))
	imprimir(describir(0))
	imprimir(describir(9))
```

## Una comparación ya es un valor

Si una función debe devolver un `bool`, no hace falta escribir un `si`. La comparación ya da `verdadero` o `falso`, y ese es el resultado.

```cometa ejecutar
fn es_par(numero entero) bool
	numero % 2 == 0

fn inicio()
	imprimir(es_par(4))
	imprimir(es_par(7))
```

## Salir antes con retornar

`retornar` termina la función en ese punto y devuelve el valor que tiene a la derecha. Se usa mucho para resolver primero los casos especiales. En el siguiente ejemplo, dividir entre cero no es posible, así que la función devuelve 0 en ese caso y no llega a hacer la división.

```cometa ejecutar
fn dividir(a entero, b entero) entero
	si b == 0
		retornar 0
	a / b

fn inicio()
	imprimir(dividir(10, 2))
	imprimir(dividir(10, 0))
```

## Pruébalo

Cambia la temperatura hasta conseguir cada uno de los tres mensajes.

```cometa ejecutar
fn inicio()
	var temperatura = 18
	si temperatura < 10
		imprimir("Hace frío")
	osi temperatura < 25
		imprimir("Está templado")
	sino
		imprimir("Hace calor")
```
