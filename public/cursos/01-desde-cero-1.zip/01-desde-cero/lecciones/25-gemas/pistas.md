`dentro` usa cuatro comparaciones que tienen que cumplirse a la vez.

```cometa
fila >= 1 && fila <= filas - 2 && columna >= 1 && columna <= columnas - 2
```
---
`mover` resuelve primero los casos en los que Lira no se debe mover, y sale del método con `retornar`.

```cometa
si @energia == 0 retornar
var fila = @fila + df
var columna = @columna + dc
si !dentro(fila, columna) retornar
```
---
Si el método sigue después de esas líneas, Lira sí se puede mover. Guarda el destino en sus campos y réstale 1 de energía.

```cometa
@fila = fila
@columna = columna
@energia -= 1
```
---
En `recoger`, una gema se recoge si todavía no está recogida y además está en la misma fila y en la misma columna que la heroína.

```cometa
repetir (gemas) |gema|
	si !gema.recogida && gema.fila == heroe.fila && gema.columna == heroe.columna
		gema.recogida = verdadero
		heroe.puntos += gema.valor
```
---
`quedan` cuenta las gemas que no están recogidas.

```cometa
var total = 0
repetir (gemas) |gema|
	si !gema.recogida
		total += 1
total
```
---
En `mensaje`, guarda primero cuántas gemas quedan y después elige entre los tres caminos. Revisa primero si ya no quedan gemas, porque si recoges la última gema con tu último paso, ganas.

```cometa
var faltan = quedan(gemas)
si faltan == 0 "¡Tienes todas las gemas!"
osi heroe.energia == 0 "Te quedaste sin energía"
sino "Faltan ${faltan} gemas"
```
