Los programas guardan datos de clases muy distintas. Si queremos guardar la información de una persona, su edad es un número y su nombre es un texto. Cometa los trata de forma diferente, y a esa clase de dato la llamamos tipo.

## ¿Qué es un tipo?

El tipo de una variable define lo que se puede hacer con ella. Dos números se pueden sumar o multiplicar, mientras que dos textos se pueden unir uno detrás del otro. Multiplicar un nombre por otro nombre no tiene sentido, y Cometa lo sabe gracias a los tipos.

En Cometa todas las variables tienen un tipo y solo pueden guardar valores de ese tipo. A los lenguajes que funcionan así se les dice lenguajes de tipado estático.

Otros lenguajes, como Python, permiten que una misma variable guarde primero un número y más adelante un texto. Cometa no lo permite. Si intentas guardar una `cadena` en una variable de tipo `entero`, verás un error.

La ventaja es que Cometa conoce el tipo de cada variable desde el principio, y eso le permite avisarte de una equivocación antes de que el programa empiece a correr.

## Los cuatro tipos básicos

- `entero` es para números sin decimales, como `3`, `0` o `-12`.
- `decimal` es para números con decimales, como `1.52` o `-0.5`. Se escriben con punto y no con coma.
- `cadena` es para texto, que siempre va entre comillas, como `"Hola"`.
- `bool` solo tiene dos valores posibles, que son `verdadero` y `falso`.

```cometa ejecutar
fn inicio()
	var edad = 12
	var altura = 1.52
	var nombre = "Ana"
	var le_gusta_leer = verdadero
	imprimir(edad)
	imprimir(altura)
	imprimir(nombre)
	imprimir(le_gusta_leer)
```

## Mostrar variables dentro de un texto

En el ejemplo anterior cada dato se imprimió en su propia línea. Muchas veces queda mejor mostrar varios datos en una misma oración. Para lograrlo, dentro de una cadena puedes escribir `${}` con el nombre de una variable entre las llaves, y Cometa pone en ese lugar el valor de la variable.

```cometa ejecutar
fn inicio()
	var nombre = "Ana"
	var edad = 12
	imprimir("${nombre} tiene ${edad} años")
```

Esto funciona con los cuatro tipos. Cambia los valores y corre el programa otra vez.

## Escribir el tipo

Hasta ahora Cometa ha reconocido el tipo de cada variable por su valor. También puedes escribirlo tú después del nombre.

```cometa ejecutar
fn inicio()
	var puntos entero = 0
	var nombre cadena = "Luis"
	var precio decimal = 2.5
	var tiene_llave bool = falso
	imprimir("${nombre}: ${puntos} puntos")
	imprimir("Precio: ${precio}. ¿Tiene llave? ${tiene_llave}")
```

Escribir el tipo no es obligatorio, pero en algunos casos ayuda a que el código se entienda mejor.

## Una variable conserva su tipo

El tipo de una variable no cambia nunca. Si `puntos` es un entero, puedes guardarle otro entero, pero no un texto.

```cometa
var puntos = 0
puntos = 25      // bien: otro entero
puntos = "hola"  // error: "hola" no es un entero
```

Esta regla evita equivocaciones. Si más adelante escribes `puntos + 1`, puedes estar seguro de que dentro de `puntos` hay un número.

## Los nombres de las variables

Un buen nombre dice qué guarda la variable. `vida` se entiende mejor que `v`, y `monedas_de_oro` se entiende mejor que `x2`. Cometa también tiene algunas reglas para los nombres.

- Se escriben sin espacios. Para separar palabras se usa el guion bajo, como en `puntos_de_vida`.
- No pueden empezar con un número.
- No pueden ser palabras que Cometa ya usa, como `var`, `fn` o `si`.

## Pruébalo

Este programa funciona bien. Ponle comillas al `25` para convertirlo en una cadena, córrelo y lee el mensaje de error. Así podrás reconocerlo cuando te aparezca sin querer. Después quita las comillas para arreglarlo.

```cometa ejecutar
fn inicio()
	var monedas entero = 10
	monedas = 25
	imprimir("Tienes ${monedas} monedas")
```

En el siguiente ejercicio vas a crear una variable de cada tipo.
