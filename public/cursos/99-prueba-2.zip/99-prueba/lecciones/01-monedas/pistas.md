Escribe la variable en la parte marcada, con `var`, el nombre `monedas` y el valor `10`.

```cometa
var monedas = 10
```
---
La función completa se ve así. La última línea ya estaba escrita.

```cometa
pub fn contar_monedas() entero
	var monedas = 10
	monedas
```
