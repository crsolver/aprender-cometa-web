Cuando usas `repetir` con un rango, sabes desde el principio cuántas vueltas va a dar el ciclo. En otros casos esa cantidad no se conoce de antemano. La cantidad de golpes que hacen falta para vencer a un monstruo, por ejemplo, depende de su vida y de tu fuerza. Lo que sí puedes decir es en qué momento hay que detenerse.

## Repetir mientras se cumpla algo

`mientras` repite las líneas de su bloque siempre que una condición sea verdadera. Antes de cada vuelta revisa la condición otra vez, y cuando la encuentra falsa, el ciclo termina.

```cometa ejecutar
fn inicio()
	var vida_del_monstruo = 20
	var golpes = 0
	mientras vida_del_monstruo > 0
		vida_del_monstruo -= 6
		golpes += 1
		imprimir("¡Golpe! Le queda ${vida_del_monstruo} de vida")
	imprimir("Vencido en ${golpes} golpes")
```

Cambia la vida inicial o la fuerza del golpe y corre el programa otra vez. El ciclo da exactamente las vueltas necesarias en cada caso.

Si la condición es falsa desde el principio, el bloque no se ejecuta ninguna vez.

## Cuidado con los ciclos infinitos

Dentro de un `mientras` tiene que cambiar algún valor que en algún momento haga falsa la condición. Si eso no pasa, el ciclo nunca termina. En el siguiente ejemplo la variable `vida` nunca cambia, así que la condición siempre es verdadera.

```cometa
var vida = 20
mientras vida > 0
	imprimir("¡Golpe!")
```

Si te llega a pasar, no se daña nada. El programa se detiene solo después de unos segundos y te avisa. Revisa entonces cuál variable debería cambiar en cada vuelta.

## Otro ejemplo

Esta función calcula cuántas semanas necesitas para comprar algo si ahorras la misma cantidad cada semana.

```cometa ejecutar
fn semanas_para(precio entero, ahorro_semanal entero) entero
	var ahorrado = 0
	var semanas = 0
	mientras ahorrado < precio
		ahorrado += ahorro_semanal
		semanas += 1
	semanas

fn inicio()
	imprimir(semanas_para(100, 15))
```

Aquí también se acumula un resultado, como hiciste con `repetir`. La diferencia es que ahora la condición decide cuándo se detiene el ciclo.

## Salir de un ciclo con romper

`romper` termina el ciclo en ese momento, aunque todavía le falten vueltas. Funciona tanto en `repetir` como en `mientras`.

```cometa ejecutar
fn inicio()
	repetir (1..100) |numero|
		si numero * numero > 50
			imprimir("El primero cuyo cuadrado pasa de 50 es ${numero}")
			romper
	imprimir("Fin de la búsqueda")
```

El rango llegaba casi hasta 100, pero el ciclo se detuvo apenas encontró el número que buscaba.

## Saltarse una vuelta con continuar

`continuar` deja la vuelta actual sin terminar y pasa a la siguiente. El ciclo sigue funcionando.

```cometa ejecutar
fn inicio()
	repetir (1..8) |numero|
		si numero == 4
			continuar
		imprimir(numero)
```

Se imprimen todos los números menos el 4.

## Repetir sin fin

Un `repetir` sin rango da vueltas sin detenerse. Solo tiene sentido usarlo si dentro hay un `romper` o un `retornar` que lo detenga.

```cometa ejecutar
fn inicio()
	var numero = 1
	repetir
		numero *= 2
		si numero > 1000
			romper
	imprimir(numero)
```

## ¿Cuál uso?

Usa `repetir` con un rango cuando sabes cuántas vueltas son o cuando quieres recorrer una serie de números. Usa `mientras` cuando lo que conoces es la condición para seguir.

## Pruébalo

Una pelota cae desde 100 metros de altura, y en cada rebote sube hasta la mitad de la altura anterior. El programa cuenta los rebotes hasta que la pelota sube menos de 1 metro. Cambia la altura inicial y observa cuánto cambia la cantidad de rebotes.

```cometa ejecutar
fn inicio()
	var altura = 100.0
	var rebotes = 0
	mientras altura >= 1
		altura /= 2
		rebotes += 1
	imprimir("Rebota ${rebotes} veces")
```
