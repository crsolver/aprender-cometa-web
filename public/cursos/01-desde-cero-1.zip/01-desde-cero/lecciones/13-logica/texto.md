Algunas decisiones dependen de más de una condición. Para abrir un cofre necesitas tener la llave y además estar frente a él. Pierdes la partida si te quedas sin vida o si se acaba el tiempo. En esta lección vas a aprender a combinar varias comparaciones en una sola pregunta.

## Las dos condiciones a la vez

`&&` se lee "y". El resultado es verdadero solo cuando las dos condiciones son verdaderas.

```cometa ejecutar
fn inicio()
	var tiene_llave = verdadero
	var esta_cerca = falso
	imprimir(tiene_llave && esta_cerca)
```

Cambia `esta_cerca` a `verdadero` y corre el programa otra vez.

Con `&&` también puedes revisar si un número está entre otros dos.

```cometa ejecutar
fn inicio()
	var edad = 15
	si edad >= 13 && edad <= 19
		imprimir("Es adolescente")
	sino
		imprimir("No es adolescente")
```

## Con una condición basta

`||` se lee "o". El resultado es verdadero cuando al menos una de las condiciones es verdadera, y solo es falso cuando las dos son falsas.

```cometa ejecutar
fn inicio()
	var vida = 0
	var tiempo = 45
	si vida == 0 || tiempo == 0
		imprimir("Fin de la partida")
	sino
		imprimir("Sigue jugando")
```

## Lo contrario de una condición

`!` se lee "no" y se escribe antes de un bool para invertirlo. Convierte `verdadero` en `falso`, y `falso` en `verdadero`.

```cometa ejecutar
fn inicio()
	var puerta_abierta = falso
	si !puerta_abierta // si la puerta no está abierta
		imprimir("La puerta está cerrada")
	imprimir(!verdadero)
```

## Combinar varias

Puedes usar `&&`, `||` y `!` en una misma condición. Los paréntesis sirven para indicar cuáles partes van juntas.

```cometa ejecutar
fn inicio()
	var tiene_llave = falso
	var sabe_hechizo = verdadero
	var esta_cerca = verdadero
	si (tiene_llave || sabe_hechizo) && esta_cerca
		imprimir("El cofre se abre")
	sino
		imprimir("El cofre sigue cerrado")
```

Cuando no hay paréntesis, Cometa resuelve primero los `&&` y después los `||`, de la misma forma en que multiplica antes de sumar. Si tienes dudas sobre el orden, escribe los paréntesis. El programa funciona igual y la condición es más fácil de leer.

## Elegir entre muchos casos

Cuando una variable puede tener muchos valores y quieres hacer algo distinto con cada uno, escribir un `osi` por cada valor resulta largo y difícil de leer. Con `casos` puedes escribir lo mismo de una forma más ordenada.

```cometa ejecutar
fn nombre_del_dia(dia entero) cadena
	casos dia
		1 => "lunes"
		2 => "martes"
		3 => "miércoles"
		4 => "jueves"
		5 => "viernes"
		6, 7 => "fin de semana"
		_ => "ese día no existe"

fn inicio()
	imprimir(nombre_del_dia(3))
	imprimir(nombre_del_dia(7))
	imprimir(nombre_del_dia(40))
```

Después de la palabra `casos` va el valor que se quiere revisar. Cada línea de adentro es un caso, y tiene un valor, la flecha `=>` y lo que se hace o se devuelve cuando el valor coincide.

Un caso puede tener varios valores separados por comas, como `6, 7`.

El guion bajo `_` significa "cualquier otro valor". Se escribe al final y es obligatorio, porque Cometa necesita saber qué hacer con los valores que no aparecen en la lista.

`casos` también funciona con cadenas.

```cometa ejecutar
fn sonido(animal cadena) cadena
	casos animal
		"perro" => "guau"
		"gato" => "miau"
		"vaca" => "muu"
		_ => "..."

fn inicio()
	imprimir(sonido("gato"))
	imprimir(sonido("dragón"))
```

## Pruébalo

Este programa decide si puedes subir a la montaña rusa. Para subir hay que medir al menos 130 cm o ir con una persona adulta. Cambia los valores y piensa cuál será la respuesta antes de correrlo.

```cometa ejecutar
fn inicio()
	var altura = 120
	var va_con_adulto = verdadero
	si altura >= 130 || va_con_adulto
		imprimir("¡Puedes subir!")
	sino
		imprimir("Todavía no")
```
