`golpes_necesarios` se resuelve con un `mientras`. Siempre que al dragón le quede vida, le quitas una parte y cuentas un golpe más.

```cometa
var golpes = 0
mientras vida > 0
	vida -= fuerza
	golpes += 1
golpes
```
---
En `oro_sin_maldicion`, recorre los cofres desde el 1 hasta el último. Si el número es múltiplo de 3, usa `continuar` para pasar al siguiente sin sumarlo.

```cometa
repetir (1..cofres + 1) |cofre|
	si cofre % 3 == 0
		continuar
	oro += cofre
```
---
En el combate, el ciclo sigue mientras las dos tengan vida. En cada vuelta golpea primero la heroína. Si el dragón se queda sin vida, el combate termina ahí con `romper` y el dragón ya no devuelve el golpe.

```cometa
mientras vida_heroina > 0 && vida_dragon > 0
	vida_dragon -= fuerza_heroina
	si vida_dragon <= 0
		romper
	vida_heroina -= fuerza_dragon
```
---
Cuando el ciclo termina, alguna de las dos se quedó sin vida. La heroína ganó si fue el dragón, y esa comparación es la última línea de la función.

```cometa
vida_dragon <= 0
```
