Cada variable va en su propia línea, con `var`, el nombre y el valor. Esta es la primera.

```cometa
var nombre = "Lira"
```
---
Los números no llevan comillas, y los decimales se escriben con punto.

```cometa
var nivel = 3
var altura = 1.6
```
---
Un bool tampoco lleva comillas, porque `verdadero` es una palabra de Cometa y no un texto.

```cometa
var es_maga = verdadero
```
---
Estas son las cuatro líneas juntas.

```cometa
var nombre = "Lira"
var nivel = 3
var altura = 1.6
var es_maga = verdadero
```
