El mercader del pueblo vende pociones, pero le cuesta mucho hacer cuentas y todas le dan 0. Ayúdale a corregirlas.

## Tu misión

En `solucion.cometa` hay cinco funciones. En cada una hay una variable que vale `0` o que tiene un texto vacío. Cambia ese valor por la operación correcta.

- `total(precio, cantidad)` devuelve lo que cuesta comprar esa cantidad de objetos.
- `cambio(monedas, costo)` devuelve el vuelto, es decir, las monedas que te quedan después de pagar.
- `para_cada_uno(monedas, amigos)` devuelve cuántas monedas le tocan a cada amigo si se reparten por igual.
- `sobran(monedas, amigos)` devuelve cuántas monedas sobran después de ese reparto.
- `recibo(objeto, total)` devuelve un texto como `"Poción: 36 monedas"`.

## Lo que necesitas saber

Las palabras que están entre paréntesis, como `precio` y `cantidad`, son datos que la función recibe cada vez que alguien la usa. Dentro de la función se usan igual que cualquier variable.

```cometa
pub fn doble(numero entero) entero
	var resultado = numero * 2
	resultado
```

Estas son las operaciones que vas a necesitar.

- `+` suma y `-` resta.
- El asterisco multiplica.
- `/` divide. Entre enteros descarta los decimales, así que `7 / 2` da `3`.
- `%` da el resto de la división, así que `7 % 2` da `1`.

Para poner valores dentro de un texto se usa `${}`.

```cometa
var mensaje = "${nombre} tiene ${edad} años"
```

Puedes resolver las funciones una por una. Presiona **Probar** cada vez que termines una para ver cuántas pruebas pasan.
