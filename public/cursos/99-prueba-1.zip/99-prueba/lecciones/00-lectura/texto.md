Te damos la bienvenida a Cometa, un lenguaje de programación con palabras en español.

Al final de este curso vas a tener un pequeño juego terminado. En él, una heroína llamada Lira recorre una cueva recogiendo gemas antes de quedarse sin energía, y cada paso que dé va a funcionar porque vas a escribir su código. Para llegar ahí no necesitas saber nada de programación. Vamos a empezar desde el principio y avanzaremos un concepto a la vez.

## ¿Qué es programar?

Programar es escribir instrucciones para que una computadora las siga. Los juegos, las aplicaciones del teléfono y las páginas que visitas todos los días existen porque alguien escribió esas instrucciones.

La computadora cumple al pie de la letra lo que le pides y lo hace muy rápido, pero no puede adivinar lo que quisiste decir. Por eso, una buena parte de aprender a programar consiste en aprender a explicar las cosas con orden y claridad.

## ¿Por qué vale la pena aprender?

Hoy en día mucho código lo escriben programas de inteligencia artificial. Aun así, una persona que entiende cómo funciona el software puede pedir con más precisión lo que necesita y darse cuenta cuando el resultado tiene un error.

Programar también es un buen ejercicio para la mente. Así como el cuerpo se fortalece con el deporte, la concentración y la lógica mejoran cuando resuelves problemas paso a paso.

Además es muy satisfactorio ver funcionar algo que hace un rato no existía y que creaste por tu cuenta.

## ¿Por qué Cometa?

La mayoría de los lenguajes de programación usan palabras en inglés, y eso obliga a muchas personas a aprender dos cosas al mismo tiempo. En Cometa las instrucciones y los mensajes de error están en español, de modo que puedes concentrarte en entender cómo se resuelve cada problema.

Lo que aprendas aquí te va a servir después. Las ideas de este curso, como las variables, las funciones y los ciclos, existen también en lenguajes como Python y JavaScript, y cuando llegues a ellos vas a reconocerlas.

Con Cometa también puedes crear videojuegos, que es una forma entretenida de practicar lo que vas aprendiendo.

## ¿Para quién es este curso?

Este curso es para cualquier persona que quiera aprender a programar, tenga 12 años o 60. Si nunca has escrito una línea de código, Cometa es el lenguaje adecuado para empezar. Si ya programas en otro lenguaje, puedes usar este curso para familirizarte con la sintaxis.

## Cómo funciona el curso

El curso tiene dos clases de lecciones. Las lecturas, como esta, explican un concepto con ejemplos que puedes modificar y correr ahí mismo. Cuando termines de leer una, presiona **Continuar**.

Los ejercicios vienen después de las lecturas. Cada uno trae un programa al que le falta una parte, y tu trabajo es escribirla. Con **Probar** revisas si tu código es correcto y con **Jugar** ves el programa funcionando. Si no sabes cómo seguir, cada ejercicio tiene pistas que puedes abrir una por una.

Tu progreso se guarda en tu computadora. Puedes abrir cualquier lección cuando quieras, ya sea para repasar o para adelantarte.

## Antes de empezar

Te vas a equivocar muchas veces, y eso le pasa también a quienes llevan años programando. Cuando algo falla, Cometa muestra un mensaje que dice qué encontró y en cuál línea. Léelo con calma, porque casi siempre indica dónde buscar.

Tampoco hace falta entender todo en la primera lectura. Cambia los ejemplos, prueba qué pasa si escribes otra cosa y vuelve a una lección anterior cuando lo necesites.

En la siguiente lección vas a crear tu primera variable y a correr tu primer programa.
