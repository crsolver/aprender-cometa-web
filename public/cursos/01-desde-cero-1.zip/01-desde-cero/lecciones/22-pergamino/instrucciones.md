En el fondo de la mochila aparece un pergamino con un mensaje muy extraño.

```
l0br4 l3 0j4b 4ts3 0r0s3t l3
```

La persona que lo escribió usó dos trucos. Cambió algunas vocales por números y además escribió todo al revés. Vas a construir las herramientas necesarias para leerlo.

## Tu misión

Completa las cinco funciones de `solucion.cometa`.

- `contar_letra(texto, letra)` devuelve cuántas veces aparece esa letra en el texto. En `"banana"`, la `"a"` aparece 3 veces.
- `al_reves(texto)` devuelve el texto con las letras en el orden contrario. `"hola"` se convierte en `"aloh"`.
- `descifrar(texto)` cambia cada `4` por una `a`, cada `3` por una `e` y cada `0` por una `o`.
- `palabras(frase)` devuelve cuántas palabras tiene la frase. Las palabras están separadas por un espacio.
- `leer(pergamino)` devuelve el mensaje completo. Primero pone el texto al derecho y después lo descifra, usando las dos funciones que ya escribiste.

## Lo que necesitas saber

`dividir("")` convierte una cadena en una lista con sus letras, y esa lista se puede recorrer.

```cometa
repetir (texto.dividir("")) |letra|
	imprimir(letra)
```

Para construir un texto se empieza con una cadena vacía y se le van añadiendo trozos. El lugar donde queda cada letra depende del orden en que las unes.

```cometa
resultado = resultado + letra   // la letra queda al final
resultado = letra + resultado   // la letra queda al principio
```

`reemplazar` devuelve un texto nuevo con los cambios, y puedes usar varios seguidos.

```cometa
var limpio = texto.reemplazar("_", " ").reemplazar("!", "")
```

`dividir(" ")` parte una frase en los espacios y devuelve la lista de palabras.
