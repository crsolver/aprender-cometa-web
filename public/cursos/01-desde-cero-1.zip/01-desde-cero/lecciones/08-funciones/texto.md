En los ejercicios anteriores escribiste código dentro de funciones que ya estaban hechas. En esta lección vas a conocer cada una de sus partes para que puedas crear las tuyas.

## ¿Qué es una función?

Ya has usado dos funciones. Una es `imprimir`, que muestra un dato en la consola, y la otra es `inicio`, que es donde empieza el programa. Una función es un grupo de instrucciones que tiene un nombre. Después de crearla puedes usarla todas las veces que quieras escribiendo solo ese nombre.

```cometa ejecutar
fn saludar()
	imprimir("¡Hola!")
	imprimir("Bienvenido a Cometa")

fn inicio()
	saludar()
	saludar()
```

La función se crea con `fn`, el nombre que elijas y un par de paréntesis. Las líneas que están debajo con un tabulador son las instrucciones que le pertenecen.

Dentro de `inicio` aparece `saludar()` dos veces. Cada vez que Cometa encuentra ese nombre va a la función, ejecuta sus dos líneas y regresa para continuar donde estaba. A esto se le dice llamar a la función. Por eso al correr el programa ves cuatro mensajes.

## Parámetros

Esta versión de `saludar` hace siempre lo mismo. Si quieres que salude a cada persona por su nombre, la función necesita recibir ese nombre en el momento en que la llamas. Los datos que una función recibe se llaman parámetros y se escriben entre los paréntesis, cada uno con su nombre y su tipo.

```cometa ejecutar
fn saludar(nombre cadena)
	imprimir("Hola, ${nombre}")

fn inicio()
	saludar("Valeria")
	saludar("Diego")
```

Dentro de la función, `nombre` se usa igual que una variable. En la primera llamada vale `"Valeria"` y en la segunda vale `"Diego"`.

Una función puede tener varios parámetros separados por comas. Al llamarla, los valores se escriben en el mismo orden que los parámetros.

```cometa ejecutar
fn presentar(nombre cadena, edad entero)
	imprimir("${nombre} tiene ${edad} años")

fn inicio()
	presentar("Valeria", 12)
	presentar("Diego", 9)
```

## Resultados

Las funciones anteriores imprimen un mensaje y terminan. Una función también puede hacer un cálculo y entregarle el resultado a quien la llamó.

Piensa en el vuelto que te dan en la pulpería cuando pagas con un billete de 5000 colones una compra de 1350. La persona que atiende recibe dos números, hace una resta y te devuelve el resultado. La siguiente función hace lo mismo.

```cometa ejecutar
fn vuelto(pago entero, precio entero) entero
	pago - precio

fn inicio()
	var mi_vuelto = vuelto(5000, 1350)
	imprimir(mi_vuelto)
	imprimir(vuelto(2000, 1350))
```

La palabra `entero` que está después de los paréntesis indica de qué tipo es el resultado. La función devuelve el valor de su última línea, que aquí es la resta. En `inicio` ese valor se guarda en la variable `mi_vuelto`, que queda con 3650.

Una llamada como `vuelto(2000, 1350)` se puede escribir en cualquier lugar donde iría un valor. Puedes guardarla en una variable, imprimirla directamente o usarla dentro de otra operación.

Antes de la última línea, una función puede tener todas las instrucciones que necesite.

```cometa ejecutar
fn precio_final(precio entero, cantidad entero) entero
	var total = precio * cantidad
	var descuento = total / 10
	total - descuento

fn inicio()
	imprimir(precio_final(20, 5))
```

Cuando la función es muy corta, se puede escribir completa en una sola línea.

```cometa ejecutar
fn doble(numero entero) entero numero * 2

fn inicio()
	imprimir(doble(21))
```

## Imprimir y devolver son cosas distintas

Es fácil confundir estas dos acciones al principio. `imprimir` muestra un valor en la pantalla y ahí termina su trabajo. Cuando una función devuelve un valor, se lo entrega a quien la llamó, y el programa puede seguir trabajando con él.

```cometa ejecutar
fn doble(numero entero) entero
	numero * 2

fn inicio()
	var resultado = doble(4) + 1
	imprimir(resultado)
```

Aquí `doble(4)` devuelve un 8, y a ese 8 se le suma 1 antes de imprimirlo. Si `doble` solamente imprimiera el 8, no habría ningún valor al cual sumarle.

En los ejercicios, tus funciones casi siempre devuelven el resultado, y el resto del programa se encarga de mostrarlo.

## Funciones que usan otras funciones

Una función puede llamar a otras funciones. Los programas grandes se construyen de esta manera, combinando funciones pequeñas que hacen una sola tarea cada una.

```cometa ejecutar
fn doble(numero entero) entero
	numero * 2

fn cuadruple(numero entero) entero
	doble(doble(numero))

fn inicio()
	imprimir(cuadruple(5))
```

## Las variables viven dentro de su función

Una variable creada dentro de una función solo existe en esa función. Las demás funciones no pueden verla, aunque tengan una variable con el mismo nombre.

```cometa ejecutar
fn contar_ovejas() entero
	var total = 3
	total

fn contar_vacas() entero
	var total = 10
	total

fn inicio()
	imprimir(contar_ovejas())
	imprimir(contar_vacas())
```

Las dos variables `total` son distintas y ninguna afecta a la otra. Por eso, para pasar datos de una función a otra se usan los parámetros y los resultados.

## ¿Y la palabra pub?

En los ejercicios, las funciones empiezan con `pub`, que viene de la palabra "público". Tu código está en un archivo y el resto del programa está en otro. `pub` permite que ese otro archivo use tu función. No cambia nada más en la función, así que no la borres.

## Resumen

- Una función se crea con `fn`, un nombre y un par de paréntesis.
- Los parámetros van entre los paréntesis, cada uno con su nombre y su tipo.
- El tipo del resultado va después de los paréntesis, y la función devuelve el valor de su última línea.

Con las variables, los tipos y las funciones ya conoces las piezas principales de un programa.
