Llegaste al último reto del curso. Esta vez el programa es un juego con ventana y teclado. Lira entra en una cueva llena de gemas, pero el juego está a medio hacer. Lira no se mueve, las gemas no se pueden recoger y el marcador no muestra nada.

Para terminarlo vas a usar lo que aprendiste sobre tipos, métodos, listas, ciclos y condiciones.

## Cómo es el juego

La cueva es una cuadrícula de `filas` × `columnas` casillas, y las casillas del borde son muros. Lira se mueve con las flechas del teclado y cada paso le cuesta 1 de energía. Cada gema vale una cantidad de puntos. El juego se gana recogiendo todas las gemas antes de quedarse sin energía.

En la parte de arriba, el corazón muestra la energía y la estrella muestra los puntos. Las gemas celestes valen 1 punto y las amarillas valen 3.

Las filas se cuentan desde arriba y las columnas desde la izquierda, y en los dos casos se empieza en 0. Por eso los muros están en la fila `0`, en la última fila (`filas - 1`), en la columna `0` y en la última columna (`columnas - 1`).

## Tu misión

Completa estas partes de `solucion.cometa` en el orden en que aparecen.

- `dentro(fila, columna)` devuelve `verdadero` si esa casilla está dentro de la cueva, es decir, si no es un muro ni está fuera de la cuadrícula. Las filas de adentro van de `1` a `filas - 2`, y las columnas de `1` a `columnas - 2`.
- `Heroe.mover(df, dc)` mueve a Lira `df` filas y `dc` columnas. Cada uno de esos dos valores puede ser `-1`, `0` o `1`. Si a Lira no le queda energía, el método no hace nada. Tampoco hace nada si la casilla de destino no está `dentro`. Si Lira se mueve, pierde 1 de energía.
- `recoger(heroe, gemas)` recorre las gemas. Cada gema que esté en la misma casilla que Lira y que todavía no esté recogida se marca como `recogida`, y su `valor` se suma a los `puntos` de Lira.
- `quedan(gemas)` devuelve cuántas gemas faltan por recoger.
- `mensaje(heroe, gemas)` devuelve el texto que aparece abajo. Si no quedan gemas, el texto es `"¡Tienes todas las gemas!"`. Si quedan gemas pero Lira no tiene energía, es `"Te quedaste sin energía"`. En cualquier otro caso es `"Faltan 4 gemas"`, con el número que corresponda.

Presiona **Probar** después de completar cada función, y **Jugar** cuando quieras ver cómo va quedando. Dentro del juego, la tecla Enter empieza una partida nueva.

## Lo que necesitas saber

Dentro de un método, los campos llevan arroba. Un `retornar` sin ningún valor a la derecha sale del método.

```cometa
pub fn descansar()
	si @energia >= 40 retornar
	@energia += 1
```

Para saber a cuál casilla iría Lira sin moverla todavía, calcula el destino en dos variables.

```cometa
var fila = @fila + df
var columna = @columna + dc
```

Cuando recorres una lista de un tipo creado por ti, cada elemento es el mismo que está en la lista y no una copia. Si lo cambias dentro del ciclo, cambia también en la lista.

```cometa
repetir (gemas) |gema|
	gema.recogida = verdadero
```

Un campo de tipo `bool` ya es una condición, y con `!` puedes preguntar lo contrario, como en `si !gema.recogida`.
