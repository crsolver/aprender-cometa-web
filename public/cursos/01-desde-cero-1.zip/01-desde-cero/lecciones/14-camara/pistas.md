`puede_entrar` necesita las dos condiciones a la vez, así que se unen con `&&`.

```cometa
nivel >= 3 && tiene_antorcha
```
---
Para el cofre basta con una de las dos condiciones.

```cometa
tiene_llave || sabe_hechizo
```

Para el pasillo hay que invertir el bool.

```cometa
!hay_trampa
```
---
"Entre 1 y 6" son dos comparaciones que deben cumplirse a la vez.

```cometa
numero >= 1 && numero <= 6
```
---
`premio` es un `casos` con el dado. Los valores que dan el mismo premio van juntos, separados por una coma.

```cometa
casos dado
	1 => "nada"
	2, 3 => "moneda"
	4, 5 => "gema"
	6 => "corona"
	_ => "dado inválido"
```
