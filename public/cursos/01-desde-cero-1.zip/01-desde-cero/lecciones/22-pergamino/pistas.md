`contar_letra` recorre las letras y cuenta las que son iguales a la buscada.

```cometa
repetir (texto.dividir("")) |actual|
	si actual == letra
		veces += 1
```
---
En `al_reves`, pon cada letra antes de lo que ya llevas. Con `"hola"` el resultado pasa por `"h"`, `"oh"`, `"loh"` y `"aloh"`.

```cometa
repetir (texto.dividir("")) |letra|
	resultado = letra + resultado
```
---
`descifrar` usa tres `reemplazar` seguidos, uno por cada número.

```cometa
texto.reemplazar("4", "a").reemplazar("3", "e").reemplazar("0", "o")
```
---
`palabras` divide la frase en los espacios y mide la lista que resulta.

```cometa
frase.dividir(" ").longitud()
```
---
`leer` no necesita ciclos. Llama a una función con el resultado de la otra.

```cometa
descifrar(al_reves(pergamino))
```
