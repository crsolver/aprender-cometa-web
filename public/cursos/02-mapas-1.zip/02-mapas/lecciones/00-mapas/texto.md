En una lista, cada dato se busca por su posición. Eso funciona bien cuando los datos van en fila, como los objetos de una mochila. Imagina que ahora quieres guardar el precio de cada objeto de una tienda. Con una lista tendrías que recordar que el precio de la espada está en la posición 0 y el del escudo en la posición 1, y sería fácil equivocarse.

Un mapa guarda cada valor junto a un nombre, y después encuentras el valor con ese nombre. A ese nombre se le llama clave.

## Crear un mapa

Un mapa se escribe entre corchetes, igual que una lista. Cada elemento tiene dos partes separadas por dos puntos. A la izquierda va la clave y a la derecha va el valor.

```cometa ejecutar
fn inicio()
	var precios = ["espada": 50, "escudo": 30, "poción": 8]
	imprimir(precios.longitud())
```

Este mapa tiene tres elementos. Las claves son los nombres de los objetos y los valores son sus precios. Todas las claves de un mapa son del mismo tipo, y todos los valores también.

## Leer un valor

Para leer un valor, escribe su clave entre corchetes después del nombre del mapa. Como la clave podría no estar en el mapa, después se escribe `o` y el valor que quieres recibir en ese caso.

```cometa ejecutar
fn inicio()
	var precios = ["espada": 50, "escudo": 30, "poción": 8]
	imprimir(precios["espada"] o 0)
	imprimir(precios["dragón"] o 0)
```

La tienda no vende dragones, así que la segunda línea imprime el 0 que está después de `o`. Es lo mismo que hacías con `obtener` en las listas.

## Agregar y cambiar

Un valor se guarda igual que en una variable, indicando su clave. Si la clave ya estaba en el mapa, el valor anterior se reemplaza. Si no estaba, el mapa gana un elemento nuevo.

```cometa ejecutar
fn inicio()
	var precios = ["espada": 50, "escudo": 30]
	precios["escudo"] = 35
	precios["arco"] = 40
	imprimir(precios["escudo"] o 0)
	imprimir(precios["arco"] o 0)
	imprimir(precios.longitud())
```

## Preguntar si una clave está

`contiene` revisa si una clave está en el mapa y responde con un bool. Para quitar un elemento se usa `eliminar` con su clave.

```cometa ejecutar
fn inicio()
	var precios = ["espada": 50, "escudo": 30]
	imprimir(precios.contiene("escudo"))
	precios.eliminar("escudo")
	imprimir(precios.contiene("escudo"))
	imprimir(precios.longitud())
```

## Recorrer un mapa

`repetir` también puede recorrer un mapa. Entre las barras se escriben dos variables. La primera recibe el valor y la segunda recibe la clave.

```cometa ejecutar
fn inicio()
	var precios = ["espada": 50, "escudo": 30, "poción": 8]
	repetir (precios) |precio, objeto|
		imprimir("${objeto} cuesta ${precio} monedas")
```

Un mapa no guarda sus elementos en fila, y por eso el orden en que salen puede cambiar de una vez a otra. Ejecuta el ejemplo varias veces y fíjate en el orden. Cuando el orden importa, es mejor usar una lista.

Si solo necesitas los valores, escribe una sola variable entre las barras. Este programa suma todos los precios.

```cometa ejecutar
fn inicio()
	var precios = ["espada": 50, "escudo": 30, "poción": 8]
	var total = 0
	repetir (precios) |precio|
		total += precio
	imprimir("Comprar todo cuesta ${total} monedas")
```

## Empezar con un mapa vacío

Un mapa vacío se escribe `[:]`. Igual que con una lista vacía, hay que escribirle el tipo, porque no tiene elementos con los que Cometa pueda reconocerlo. El tipo de un mapa se escribe con el tipo de las claves, dos puntos y el tipo de los valores.

```cometa ejecutar
fn inicio()
	var edades [cadena: entero] = [:]
	edades["Ana"] = 12
	edades["Luis"] = 14
	imprimir(edades.longitud())
	imprimir(edades["Luis"] o 0)
```

`[cadena: entero]` quiere decir "mapa con claves de tipo cadena y valores de tipo entero". El tipo se escribe de la misma forma cuando una función recibe o devuelve un mapa.

## Contar con un mapa

Un mapa sirve muy bien para contar cuántas veces aparece cada cosa. La clave es lo que estás contando y el valor es la cantidad que llevas.

```cometa ejecutar
fn inicio()
	var mochila = ["poción", "llave", "poción", "cuerda", "poción"]
	var cantidades [cadena: entero] = [:]
	repetir (mochila) |objeto|
		cantidades[objeto] += 1
	imprimir("Pociones: ${cantidades["poción"] o 0}")
	imprimir("Llaves: ${cantidades["llave"] o 0}")
	imprimir("Objetos distintos: ${cantidades.longitud()}")
```

La primera vez que aparece un objeto, su clave todavía no está en el mapa. En ese caso `+=` empieza a contar desde 0, así que no hace falta revisar antes si la clave existe.

## Pruébalo

Cambia las cantidades y agrega objetos nuevos al mapa. Después cambia el programa para que también avise cuando de un objeto queda solo uno.

```cometa ejecutar
fn inicio()
	var existencias = ["espada": 2, "escudo": 0, "poción": 5]
	repetir (existencias) |cantidad, objeto|
		si cantidad == 0
			imprimir("Se acabó: ${objeto}")
		sino
			imprimir("${objeto}: quedan ${cantidad}")
```
