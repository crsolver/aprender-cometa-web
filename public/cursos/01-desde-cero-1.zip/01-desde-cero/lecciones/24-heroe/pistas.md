El campo nuevo va dentro del tipo, con un tabulador, debajo de `pub vida entero = 100`.

```cometa
pub monedas entero
```
---
En `recibir_golpe`, primero resta la fuerza. Si la vida quedó por debajo de 0, corrígela después.

```cometa
@vida -= fuerza
si @vida < 0 @vida = 0
```
---
`esta_vivo` es una comparación.

```cometa
@vida > 0
```

En `comprar` hay dos caminos. Si las monedas no alcanzan, sal del método con `retornar falso`.

```cometa
si @monedas < precio
	retornar falso
@monedas -= precio
verdadero
```
---
La descripción usa los tres campos dentro de un texto.

```cometa
"${@nombre}: ${@vida} de vida, ${@monedas} monedas"
```
---
`vivos` recorre el equipo y le pregunta a cada héroe con su método.

```cometa
repetir (equipo) |heroe|
	si heroe.esta_vivo()
		total += 1
```
---
`tormenta` recorre el equipo y llama a `recibir_golpe` con cada héroe.

```cometa
repetir (equipo) |heroe|
	heroe.recibir_golpe(fuerza)
```
