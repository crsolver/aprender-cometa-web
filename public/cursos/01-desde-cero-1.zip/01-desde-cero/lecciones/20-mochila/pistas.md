En `peso_total`, recorre la lista y suma cada peso al total.

```cometa
repetir (pesos) |peso|
	total += peso
```
---
En `mas_pesado`, guarda el peso mayor que hayas visto hasta el momento. Si encuentras uno más grande, lo reemplazas.

```cometa
repetir (pesos) |peso|
	si peso > mayor
		mayor = peso
```
---
En `cuantas`, compara cada objeto con el buscado y cuenta los que son iguales.

```cometa
repetir (objetos) |objeto|
	si objeto == buscado
		veces += 1
```
---
En `ligeros`, agrega a la lista nueva solo los pesos que no pasan del límite.

```cometa
repetir (pesos) |peso|
	si peso <= limite
		resultado.agregar(peso)
```
---
`primero` se resuelve en una línea. El primer elemento está en el índice 0.

```cometa
objetos.obtener(0) o "nada"
```
